# CodeAlpha Calculator

A responsive calculator built with HTML, CSS, and JavaScript.

## Features

- Addition, subtraction, multiplication, and division
- Decimal values, sign changes, percentage calculations, and clear/reset
- Live result preview while entering an operation
- Keyboard support for digits, operators, Enter, Escape/C, and Backspace

## Run it

Open `index.html` in a modern browser. No installation or dependencies are required.
