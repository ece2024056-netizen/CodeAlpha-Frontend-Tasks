# CodeAlpha Image Gallery

A responsive photo gallery called **Field Notes**.

## Features

- Category filters for nature, urban, portrait, and travel images
- Local photographic image assets - no external image hosting required
- Lightbox viewer with next/previous controls and keyboard navigation
- Responsive grid layout, hover effects, and accessible controls

## Run it

Open `index.html` in a browser. Keep the `images` folder in the same project folder because it contains the 16 gallery photos.
