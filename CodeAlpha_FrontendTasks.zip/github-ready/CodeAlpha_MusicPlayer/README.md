# CodeAlpha Music Player

A browser-based music player interface called **Afterglow**.

## Features

- Play, pause, previous, next, seek, volume, and autoplay controls
- Playlist with track title, artist, and duration display
- Keyboard controls: Space, left arrow, and right arrow
- Original ambient tones generated in the browser, so no external audio files are needed

## Run it

Open `index.html` in a modern browser, then press Play. The browser may request audio permission or require the Play button to be pressed before sound begins.
