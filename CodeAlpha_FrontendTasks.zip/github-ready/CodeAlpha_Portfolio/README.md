# CodeAlpha Portfolio

A responsive personal frontend portfolio for Saptarshi Sarkar.

## Features

- About, skills, selected work, résumé/contact, and footer sections
- Smooth scrolling and on-scroll reveal animations
- Responsive layout for desktop and mobile
- Links to the image gallery and calculator when used from the parent `github-ready` folder

## Customize before publishing

Replace `hello@example.com` in `index.html` with your own email address. You can also replace the project text and add your own résumé link.

## Run it

Open `index.html` in a modern browser. No installation or dependencies are required.
